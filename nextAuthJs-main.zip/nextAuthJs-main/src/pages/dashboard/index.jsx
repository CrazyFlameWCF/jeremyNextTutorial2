const Dashboard = () => {
  return (
    <div>
      <p>Dashboard Page</p>
    </div>
  );
}
export default Dashboard;