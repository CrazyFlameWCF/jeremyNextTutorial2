const DashboardSettings = () => {
  return (
    <p>Dashboard - Setting</p>
  );
}
export default DashboardSettings;