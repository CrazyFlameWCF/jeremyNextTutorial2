const DashboardAccount = () => {
  return (
    <p>Dashboard - Account</p>
  );
}
export default DashboardAccount;